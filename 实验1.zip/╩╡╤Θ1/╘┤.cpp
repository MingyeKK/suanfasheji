#include<iostream>
#include<fstream>
using namespace std;
int gary[100][100];
void gray(int a, int b)
{
	if (b == 1)
	{
		gary[0][0] = 0;
		gary[1][0] = 1;
		return;
	}
	for (int i = 0; i<a / 2; i++)
	{
		gary[i][b - 1] = 0;
		gary[a - i - 1][b - 1] = 1;
	}
	gray(a / 2, b - 1);
	for (int i = a / 2; i<a; i++) //������Ͱ벿��
		for (int j = 0; j<b - 1; j++)
			gary[i][j] = gary[a - i - 1][j];
}

int main()
{
	ifstream fin("input.txt");
	ofstream fout("output.txt");
	int b;
	fin >> b;
	int a = pow(2, b);  //���������
	gray(a, b);
	for (int i = 0; i<a; i++)
	{
		for (int j = b - 1; j >= 0; j--)
			fout << gary[i][j];
		fout << endl;
	}
	fin.close();
	return 0;
}