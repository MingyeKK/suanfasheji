#include <iostream>
using namespace std;
int a[10][10];
int cross(int m, int n) {

	int i, j;
	for (i = 1; i <= m; i++) {
		for (j = 1; j <= n; j++) {
			a[i][j] = a[i - 1][j] + a[i][j - 1];
		}
	}
	return a[m - 1][n - 1];
}
int main() {

	int m, n, i, j, sum;
	cin >> m >> n;

	for (i = 0; i <= m; i++) {
		for (j = 0; j <= n; j++) {
			a[i][j] = 1;
		}
	}
	a[0][0] = 0;

	sum = cross(m, n);
	cout << sum;

}