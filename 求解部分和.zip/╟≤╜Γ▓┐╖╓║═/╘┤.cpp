#include <iostream>
#include<map>
using namespace std;
int n, k;
int a[50];
bool flag = false;
int sum = 0;

void dfs(int p, int i)
{
	if (p == 0)flag = true;
	if (flag || i >= n)return;
	dfs(p - a[i], i + 1);
	dfs(p, i + 1);
}

int main()
{
	cin >> n >> k;
	for (int i = 0; i<n; i++) {
		cin >> a[i];
		sum += a[i];
	}
	dfs(k, 0);
	cout << (flag ? "YES" : "NO") << endl;
	return 0;
}