#include<iostream>
using namespace std;
int n;
int a[10005];
int b[10005];
int ans = 0;
void merge(int L, int R) {
	int mid = (L + R) / 2;
	int l = L;
	int r = mid + 1;
	int count = 0;
	while (l <= mid && r <= R) {
		if (a[l] < a[r]) {
			b[count++] = a[r++];
		}
		else {
			b[count++] = a[l++];
			ans += R - r + 1;
		}
	}
	while (l <= mid) {
		b[count++] = a[l++];
	}
	while (r <= R) {
		b[count++] = a[r++];
	}
	for (int i = L; i <= R; i++) {
		a[i] = b[i - L];
	}
}
void MergeSortAndCount(int L, int R) {
	if (L < R) {
		int mid = (L + R) / 2;
		MergeSortAndCount(L, mid);
		MergeSortAndCount(mid + 1, R);
		merge(L, R);
	}
}
int main() {
	cin >> n;
	for (int i = 0; i < n; i++)
		cin >> a[i];
	MergeSortAndCount(0, n - 1);
	cout << ans;
	return 0;
}