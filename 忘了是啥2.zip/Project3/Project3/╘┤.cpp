#include<iostream>
using namespace std;
void reverse(char a[], int low, int high) {
	int i = low; int j = high, temp;
	while (i < j) {
		temp = a[i];
		a[i] = a[j];
		a[j] = temp;
		i++;
		j--;
	}
 }
void lmove(char a[], int n, int length) {
	reverse(a, 0, length - 1);
	reverse(a, 0, length - n - 1);
	reverse(a, length - n, length - 1);
}
int main() {
	int len, m;
	cin >> len;
	cin >> m;
	char a[100];
	for (int i = 0; i < len; i++)
		cin >> a[i];
	lmove(a, m, len);
	for(int i=0;i<len;i++)
		cout << a[i];
	return 0;
}