#include<iostream>
#include<fstream>
using namespace std;

int a[100][100] = { 0 };

void yacht(int n) 
{
	for (int m = 1; m <= n - 1; m++)
	{
		for (int i = 1; i <= n - m; i++)
		{
			int j = i + m;
			for (int k = i; k <= j; k++)
			{
				int sum = a[i][k] + a[k][j];
				if (sum < a[i][j])
					a[i][j] = sum;
			}
		}
	}
}

int main()
{
	ifstream fin("input.txt");
	ofstream fout("output.txt");
	int n;
	//cin >> n;
	fin >> n;
	for (int i = 1; i < n; i++)
	{
		for (int j = i + 1; j <= n; j++)
		{
			fin >> a[i][j];
			//cin >> a[i][j];
		}
	}
	yacht(n);
	fout << a[1][n] << endl;
	//cout <<a[1][n] << endl;
}