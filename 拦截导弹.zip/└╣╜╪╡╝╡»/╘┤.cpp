#include<iostream>
using namespace std;
int main() {
	int i, j, k, a[100], b[100] = { 0 }, sum=0;
	cin >> k;
	for (i = 0; i <= k - 1; i++)
		cin >> a[i];
	for (i = 0; i < k; i++)
	{
		for (j = 0; j <= i; j++)
		{
			if(a[j]>=a[i]&&b[i]<=b[j])
				b[i] = b[j];
		}
		b[i]++;
		if (sum < b[i])
			sum = b[i];
	}
	cout << sum << endl;
}