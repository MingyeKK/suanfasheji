#include<iostream>
using namespace std;
int map[5][5];
int dx[4] = { 1,-1,0,0 };
int dy[4] = { 0,0,-1,1 };
int front = 0, rear = 1;
struct node {
	int x, y, pre;
}path[100];

void print(int i)
{
	if (path[i].pre != -1)
	{
		print(path[i].pre);
		cout << "(" << path[i].x << ", " << path[i].y << ")" << endl;
	}
}
void bfs(int x, int y)
{
	path[front].x = x;
	path[front].y = y;
	path[front].pre = -1;
	while (front<rear)
	{
		for (int i = 0; i<4; i++)
		{
			int pathX = dx[i] + path[front].x;
			int pathY = dy[i] + path[front].y;
			if (pathX<0 || pathX >= 5 || pathY<0 || pathY >= 5 || map[pathX][pathY])
				continue;
			else
			{
				map[pathX][pathY] = 1;
				path[rear].x = pathX;
				path[rear].y = pathY;
				path[rear].pre = front;
				rear++;
			}
			if (pathX == 4 && pathY == 4) print(front);
		}
		front++;
	}
}

int main()
{
	for (int i = 0; i<5; i++)
		for (int j = 0; j<5; j++)
			cin >> map[i][j];
	cout << "(0, 0)" << endl;
	bfs(0, 0);
	cout << "(4, 4)" << endl;
	return 0;
}
