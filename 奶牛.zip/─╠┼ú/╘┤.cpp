#include<iostream>
using namespace std;
int cow(int Cow[100][2], int B[], int n)
{
	int count = 0;
	B[0] = 1;
	int j = 0;
	count++;
	for (int i = 1; i < n; i++)
	{
		for (j = 0; j < i; j++) {
			if (Cow[i][0] > Cow[j][1])
			{
				B[i] = B[j];
			}
			
		}
		if (B[i] == 0) 
		{
			B[i] = ++count;
		}
	}
	return count;
}
int main()
{
	int Cow[100][2];
	int n;
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < 2; j++)
		{
			cin >> Cow[i][j];
		}
	}
	int B[100] = { 0 };
	cout << cow(Cow, B, n) << endl;
	for (int i = 0; i < n; i++)
	{
		cout << B[i]<<endl;
	}
	return 0;
}