#include <iostream>
using namespace std;

char s1[10], s2[10];
int dp[10][10], status[10][10];
int len1, len2;
void hebing(int len1, int len2) {
	int i=0, j=0;
	for (i = 0; i <= len1; i++) {
		dp[0][j] = 0;
	}
	for (j = 0; j <= len2; j++) {
		status[i][0] = 0;
	}
	for (int i = 1; i <= len1; i++) {
		for (int j = 1; j <= len2; j++) {
			if (s1[i] == s2[j]) {
				dp[i][j] = dp[i - 1][j - 1] + 1;
				status[i][j] = 1; //left:0; left-above:1; above:2;
			}
			else if (dp[i - 1][j]>dp[i][j - 1]) {
				dp[i][j] = dp[i - 1][j];
				status[i][j] = 2;
			}
			else {
				dp[i][j] = dp[i][j - 1];
				status[i][j] = 0;
			}
		}
	}
}
void print(int x, int y) {

	if (x == 0 && y == 0)
		return;
	if (status[x][y] == 0) {
		print(x, y - 1);
		cout<<s2[y];

	}
	else if (status[x][y] == 1) {
		print(x - 1, y - 1);
		cout<< s1[x];

	}
	else {
		print(x - 1, y);
		cout<<s1[x];

	}
}
int main()
{

	cin>>s1 + 1>>s2 + 1;

	len1 = strlen(s1 + 1);
	len2 = strlen(s2 + 1);

	hebing(len1, len2);
	print(len1, len2);

	return 0;
}
