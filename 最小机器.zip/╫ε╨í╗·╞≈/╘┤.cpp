#include<iostream>
using namespace std;
int c[100][100];
int w[100][100];
int n, m, d;
int cc=0, cw=0, sum=0;
int mi[100];
int x[100];
void backtrack(int i)
{
	if (i > n)
	{
		sum = cw;
		for (int j = 1; j <= n; j++)
			mi[j] = x[j];
	}
	else
	{
		for (int j = 1; j <= m; j++)
		{
			if (cc + c[i][j] <= d && cw + w[i][j] < sum) {
				x[i] = j;
				cw += w[i][j];
				cc += c[i][j];
				backtrack(i + 1);
				cw -= w[i][j];
				cc -= c[i][j];
			}
		}
	}
}
int main()
{
    cin>>n>>m>>d;
    for(int i=1;i<=n;i++)
      for(int j=1;j<=m;j++)
        cin>>w[i][j];
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= m; j++)
			cin >> c[i][j];
		sum += c[i][1];
	}
    backtrack(1);
	for (int i = 1; i < n; i++)
	{
		cout << mi[i] << ' ';
	}
	cout << mi[n]<<endl;
    cout<<sum<<endl;
    return 0;
}