#include<iostream>
using namespace std;
int ans;
bool prime(int x) {//�����ж�
	for (int i = 2; i <= (sqrt(double(x))); i++)
		if (x%i == 0)
			return false;
	return true;
}
bool smith(int x) {//ʷ��˹���ж�
	int Sum = 0;
	int a[10000];
	int len = 0;
	for (int i = 2; i*i <= x; i++)
	{
		while (x%i == 0)
		{
			a[len++] = i;
			x=x/ i;
		}
	}
	if (x>1)
		a[len++] = x;
	for (int j = 0; j < len; j++) {
		while (a[j] > 0) {
			Sum = Sum + a[j] % 10;
			a[j] = a[j] / 10;
		}
	}
	if (Sum == ans)
		return true;
	else
		return false;
}
int main() {
	int b[3],c[3],tem;
	for (int i = 0; i < 3; i++)
	{
		cin >> tem;
		b[i] = tem;
		if (tem == 0)
			return true;
		while (true) {
			b[i]++;
			if (!prime(b[i])) {
				ans = 0;
				int temp = b[i];
				while (temp > 0) {
					ans = ans + temp % 10;
					temp = temp / 10;
				}
				if (smith(b[i])) {
					c[i] = b[i];
					break;
				}
			}
		}
	}
	for (int i = 0; i < 3; i++) {
		cout << c[i]<<"\n";
	}
}